Kuramoto simulation in python
==============================

kuramoto_util is a python package for Kuramoto model simulations.

Required Packages
======================
* numpy
* scipy
* matplotlib
* pyfftw
* tqdm
* torusgrid
* michael960lib

Modules
========

