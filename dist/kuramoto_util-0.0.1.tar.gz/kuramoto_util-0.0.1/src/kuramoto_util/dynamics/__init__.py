from ._dynamics import KuramotoEvolver
