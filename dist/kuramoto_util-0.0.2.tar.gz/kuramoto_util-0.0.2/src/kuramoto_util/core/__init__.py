from ._core import KuramotoBase, KuramotoStateFunction

