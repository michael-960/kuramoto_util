from ._sampling import DistributionSampling, Uniform, Gaussian, Lorentzian
