from ._weights import ParametrizedWeight, PowerLaw, NearestNeighbor
